import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavLinkProps {
  icon: LucideIcon;
  text: string;
  id: string;
}

const NavLink = ({ icon: Icon, text, id }: NavLinkProps) => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <button
      onClick={() => scrollToSection(id)}
      className="group flex items-center space-x-1 text-gray-600 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-500 transition-colors"
    >
      <Icon size={18} className="group-hover:scale-110 transition-transform" />
      <span>{text}</span>
    </button>
  );
};

export default NavLink;