import React from 'react';
import { Home, User, Code2, FolderGit2, Mail, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import NavLink from './NavLink';

const Navbar = () => {
  const { isDarkMode, toggleTheme } = useTheme();

  const navLinks = [
    { icon: Home, text: 'Home', id: 'home' },
    { icon: User, text: 'About', id: 'about' },
    { icon: Code2, text: 'Skills', id: 'skills' },
    { icon: FolderGit2, text: 'Projects', id: 'projects' },
    { icon: Mail, text: 'Contact', id: 'contact' },
  ];

  return (
    <div className="fixed top-0 left-0 right-0 flex justify-center z-50 px-4 pt-6">
      <nav className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm rounded-2xl shadow-lg px-8 py-4 max-w-3xl w-full border border-gray-200/50 dark:border-gray-700/50 theme-transition">
        <div className="flex items-center justify-between">
          <div className="flex-shrink-0 font-bold text-xl bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
            Rajarshi's Portfolio
          </div>
          <div className="flex items-center space-x-8">
            <div className="hidden md:flex space-x-6">
              {navLinks.map((link) => (
                <NavLink key={link.id} {...link} />
              ))}
            </div>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle theme"
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5 text-red-600" />
              ) : (
                <Moon className="w-5 h-5 text-red-600" />
              )}
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;